﻿using System;
using System.Collections.Generic;

interface IRefreshable
{
    void Refresh();
}
