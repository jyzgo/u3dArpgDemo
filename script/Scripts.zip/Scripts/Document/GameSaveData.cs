﻿using System;
using System.Collections;
using System.Collections.Generic;

public class GameSaveData
{
	public int _sc;
	public int _hc;
	
	// empty save data initialize.
	public GameSaveData() {
		_sc = 0;
		_hc = 0;
	}
}



