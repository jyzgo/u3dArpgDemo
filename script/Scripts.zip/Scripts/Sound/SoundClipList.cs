using UnityEngine;
using System;
using System.Collections;

public class SoundClipList : ScriptableObject
{
	public SoundClip[]  _soundList;
}	

