using UnityEngine;
using System.Collections;

public interface TimerCallBack {

	void onTimeUp(int id, float passTime);
}
