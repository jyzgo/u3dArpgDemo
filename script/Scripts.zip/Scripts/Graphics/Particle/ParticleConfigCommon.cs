using UnityEngine;
using System.Collections;

public class ParticleConfigCommon : ParticleConfigBase {


}
