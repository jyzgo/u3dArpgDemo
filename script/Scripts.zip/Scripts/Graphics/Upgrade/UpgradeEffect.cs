using UnityEngine;
using System.Collections;

public class UpgradeEffect : MonoBehaviour {

	public virtual void SetGrade(int grade) {
	}
}
