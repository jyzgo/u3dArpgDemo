using UnityEngine;
using System.Collections;

public class BulletDisplayer : MonoBehaviour {
	
	virtual public void StartEffect() {
	}
	
	virtual public float EndEffect() {
		return 0.0f;
	}
}
