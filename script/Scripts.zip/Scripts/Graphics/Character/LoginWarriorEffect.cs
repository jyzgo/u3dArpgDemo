using UnityEngine;
using System.Collections;

public class LoginWarriorEffect : LoginCharEffect {


}
