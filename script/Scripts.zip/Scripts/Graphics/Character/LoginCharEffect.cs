using UnityEngine;
using System.Collections;

public class LoginCharEffect : MonoBehaviour {
	
	virtual public void UpdateEffect(float effect) {
	}
	
	virtual public void ShowEffect() {
	}
	
	virtual public void ShowEffect1() {
	}
	
	virtual public void ShowEffect2() {
	}
}
