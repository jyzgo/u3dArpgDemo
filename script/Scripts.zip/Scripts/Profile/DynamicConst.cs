using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DynamicConst : ScriptableObject {

 	public List<string> defaultEquipment_1 = new List<string>();
	public List<string> defaultEquipment_2 = new List<string>();
	public List<string> defaultEquipment_3 = new List<string>();
	
	public string installVersion = "0.1.0";
}
