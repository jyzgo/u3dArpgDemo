﻿using UnityEngine;
using System.Collections;

public class BubbleEffect : MonoBehaviour 
{
	public UILabel _text;
	public UILabel _text2;
	public GameObject _sprite;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
