﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class UISummaryPlayerCard : MonoBehaviour
{
	public UISprite _portrait;
	public UILabel _playerName;
	public UILabel _result;
	public UISprite _winnerBG;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
