using UnityEngine;
using System.Collections;

public class AniSwitch {
	
	public FC_All_ANI_ENUM _aniIdx;
	public AvatarController.AnimType _type;
	public int _parameter;
	
}
