using UnityEngine;
using System.Collections;

//only receive damage message, should in damage layer
public class DamageMessageReciever : MessageReciever {
}
