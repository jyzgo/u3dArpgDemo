using UnityEngine;
using System.Collections;

public class FCArmor : FCEquipmentsBase
{
	public string _normalTexturePath;
	public Color _customColor;
}
