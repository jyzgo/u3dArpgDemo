using UnityEngine;
using System.Collections;

public class EquipmentsList : MonoBehaviour {

	public GameObject[] _equipList;
}
