using UnityEngine;
using System.Collections;

public class FCWayPoints : MonoBehaviour {

	public string _name = "";
	public Transform[] _wayPoints = null;
}
