using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LootTrigger : MonoBehaviour {
	
	public List<Vector3> _lootPos = new List<Vector3>();
	
}
