﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using InJoy.RuntimeDataProtection;


public class OfferingDataList : ScriptableObject
{
    public List<OfferingData> dataList = new List<OfferingData>();	
}
