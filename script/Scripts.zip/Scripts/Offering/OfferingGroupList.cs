﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using InJoy.RuntimeDataProtection;



public class OfferingGroupList : ScriptableObject
{
    public List<OfferingGroup> dataList = new List<OfferingGroup>();	
}
