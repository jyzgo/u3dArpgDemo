using UnityEngine;
using System.Collections;

public class HeroEquipmentWeight : ScriptableObject {

	public PropertyWeightDataList _weaponWeight;
	public PropertyWeightDataList _helmWeight;
	public PropertyWeightDataList _shoulderWeight;
	public PropertyWeightDataList _beltWeight;
	public PropertyWeightDataList _armpieceWeight;
	public PropertyWeightDataList _leggingsWeight;
	public PropertyWeightDataList _necklaceWeight;
	public PropertyWeightDataList _ringWeight;
	
}
