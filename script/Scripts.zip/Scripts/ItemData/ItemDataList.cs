using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ItemDataList : ScriptableObject
{
    public List<ItemData> _dataList = new List<ItemData>();
}
