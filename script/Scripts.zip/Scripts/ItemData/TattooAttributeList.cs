﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class TattooAttributeList : ScriptableObject
{
	public List<AIHitParams> dataList = new List<AIHitParams>();
}
