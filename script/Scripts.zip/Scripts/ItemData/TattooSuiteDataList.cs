using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class TattooSuiteDataList : ScriptableObject
{
	public List<TattooSuiteData> dataList = new List<TattooSuiteData>();
}