using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class TattooExchangeDataList : ScriptableObject
{
	public List<TattooExchangeData> dataList = new List<TattooExchangeData>();
}